import { TrimDescriptionPipe } from './trim-description.pipe';

describe('TrimDescriptionPipe', () => {
  it('create an instance', () => {
    const pipe = new TrimDescriptionPipe();
    expect(pipe).toBeTruthy();
  });
});
