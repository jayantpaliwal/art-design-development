export interface product{
    name:string;
    price:BigInteger;
    quantity:BigInteger;
    height :string;
    width : string;
    depth : string;
    
    
}